﻿using Microsoft.EntityFrameworkCore;
using ProductCategory.Models;
using System.Collections.Generic;

namespace ProductCategory.Context
{
    public class GeneralContext : DbContext
    {
        public GeneralContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasOne<Category>(s => s.Category)
                .WithMany(s => s.Products)
                .HasForeignKey(s => s.CategoryId);
            modelBuilder.Entity<Category>().HasData(
              new Category { Id = 1, Name = "Category 1" },
              new Category { Id = 2, Name = "Category 2" }
          );

            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Product 1", Price = 10.00m, CategoryId = 1 },
                new Product { Id = 2, Name = "Product 2", Price = 20.00m, CategoryId = 1 },
                new Product { Id = 3, Name = "Product 3", Price = 30.00m, CategoryId = 2 },
                new Product { Id = 4, Name = "Product 4", Price = 40.00m, CategoryId = 2 },
                new Product { Id = 5, Name = "Product 5", Price = 50.00m, CategoryId = 2 }
            );
            base.OnModelCreating(modelBuilder);
        }
    }
}
