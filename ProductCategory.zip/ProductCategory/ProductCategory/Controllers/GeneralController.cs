﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProductCategory.Models;

namespace ProductCategory.Context
{
    public class GeneralController : Controller
    {
        private readonly GeneralContext db;

        public GeneralController(GeneralContext context)
        {
            db = context;
        }
        public IActionResult CategoryProducts(int categoryId)
        {
            var category = db.Categories
        .Include(c => c.Products)
        .SingleOrDefault(c => c.Id == categoryId);

            if (category == null)
            {
                return View("Error"); // veya başka bir view döndürebilirsiniz
            }

            return View(category);
        }
        public ActionResult Index()
        {
            var products = db.Products.Include(p => p.Category);
            return View(products.ToList());
        }

        public ActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", product.CategoryId);
            return View(product);
        }
    }
}
